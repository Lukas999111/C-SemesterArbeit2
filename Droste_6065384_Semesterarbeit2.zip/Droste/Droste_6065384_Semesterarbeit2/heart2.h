#ifndef HEART2_H
#define HEART2_H
#include <QGraphicsRectItem>
#include <QObject>
#include "enemy.h"

class heart2: public QObject,public QGraphicsEllipseItem
{
    Q_OBJECT
};

#endif // HEART2_H
