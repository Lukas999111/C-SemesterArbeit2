#include "heart2.h"
#include <QKeyEvent>
#include <QGraphicsScene>


